// Protótipo dimensional NÃO VALIDADO para uso comercial ou estrutural.
// Interface candidata: CAD beta de AHAC EL, Printables 1133098.
// Desenho próprio dos módulos; interface ainda requer ensaio físico.
$fn=96;
peca="base";
diametro_bucha=28;
folga_diametral=0.6;
furos_oem=[[58.10935,-1.01371],[-16.06119,-55.94250],[-14.63087,56.77056]];

module prisma_hex(af,h) { cylinder(d=af/cos(30),h=h,$fn=6); }
// Furo horizontal com teto a 45°; eixo X. Não exige suporte interno.
module furo_gota(d,comprimento) {
    rotate([90,0,90]) linear_extrude(height=comprimento,center=true)
        union() {
            circle(d=d,$fn=48);
            polygon([[-d/2*sqrt(0.5),d/2*sqrt(0.5)],
                     [0,d/2*sqrt(2)],
                     [d/2*sqrt(0.5),d/2*sqrt(0.5)]]);
        }
}
module placa_arredondada(w,l,h,r=5) {
    hull() for(x=[-w/2+r,w/2-r],y=[-l/2+r,l/2-r])
        translate([x,y,0]) cylinder(r=r,h=h);
}

module base() {
    difference() {
        union() {
            cylinder(d=140,h=10);
            for(x=[-85,85]) translate([x,0,0]) placa_arredondada(44,80,10);
            // Espigão sextavado transmite torção; pino passante retém o módulo.
            translate([0,0,10]) prisma_hex(44,28);
        }
        for(p=furos_oem) {
            translate([p[0],p[1],-1]) cylinder(d=7,h=12);
            translate([p[0],p[1],4]) cylinder(d=14,h=7);
        }
        for(x=[-85,85],y=[-32,32])
            translate([x,y,-1]) cylinder(d=6.6,h=12);
        translate([0,0,28]) furo_gota(6.6,65);
    }
}

module porta_vara() {
    difference() {
        union() {
            placa_arredondada(44,80,8);
            cylinder(d=46,h=150);
            // Reforço gradual na raiz; nenhuma saliência começa no ar.
            cylinder(d1=54,d2=46,h=24);
        }
        translate([0,0,8]) cylinder(d=36,h=143);
        // Drenagem e acesso inferior; este módulo NÃO veda a tampa do casco.
        translate([0,0,-1]) cylinder(d=8,h=10);
        for(y=[-32,32]) translate([0,y,-1]) cylinder(d=6.6,h=11);
        translate([0,0,22]) furo_gota(6.6,60);
    }
}

module guarda_sol() {
    difference() {
        union() {
            cylinder(d=56,h=150);
            cylinder(d1=68,d2=56,h=36);
        }
        // Entrada sextavada, seguida de transição inclinada autoportante.
        translate([0,0,-1]) prisma_hex(44+folga_diametral,30);
        hull() {
            translate([0,0,28]) prisma_hex(44+folga_diametral,0.1);
            translate([0,0,39]) cylinder(d=36,h=0.1);
        }
        translate([0,0,38.9]) cylinder(d=36,h=112);
        translate([0,0,18]) furo_gota(6.6,80);
        // Dois cortes para aperto por abraçadeira metálica na extremidade.
        for(a=[0,90]) rotate([0,0,a])
            translate([-1,-32,95]) cube([2,64,56]);
        // Canal raso para a abraçadeira, sem saliência em balanço.
        translate([0,0,127]) difference() {
            cylinder(d=60,h=13);
            cylinder(d=55,h=13);
        }
    }
}

module bucha(d=28) {
    // Imprimir com a flange apoiada na mesa; inserir invertida no tubo.
    difference() {
        union() {
            cylinder(d=40,h=3);
            translate([0,0,3]) cylinder(d=35.5,h=60);
        }
        translate([0,0,-1]) cylinder(d=d+0.5,h=65);
        translate([-0.8,0,-1]) cube([1.6,25,65]);
    }
}

module montagem() {
    color("SlateGray") base();
    color("DarkOrange") translate([0,0,10]) guarda_sol();
    for(x=[-85,85]) color("RoyalBlue") translate([x,0,10]) porta_vara();
    color("Gold") translate([0,0,163]) rotate([180,0,0]) bucha(28);
}

if(peca=="base") base();
if(peca=="porta_vara") porta_vara();
if(peca=="guarda_sol") guarda_sol();
if(peca=="bucha") bucha(diametro_bucha);
if(peca=="montagem") montagem();
